#ifndef SNDIO_H
#define SNDIO_H

void Sndio__read_samples_step(int*sample_size,float*samples) ;
void Sndio__write_samples_step(int*sample_size,float*samples) ;


#endif
